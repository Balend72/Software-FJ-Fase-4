import unittest

from main import (
    Client, EquipmentRental, RoomReservation, SoftwareFJ,
    SpecializedConsulting, ValidationError, ServiceUnavailableError
)


class SoftwareFJTests(unittest.TestCase):
    def setUp(self):
        self.app = SoftwareFJ()
        self.client = Client("C1", "Ana Pérez", "ana@example.com", "3001234567")
        self.room = RoomReservation("S1", 50000, 10)
        self.app.add_client(self.client)
        self.app.add_service(self.room)

    def test_invalid_email(self):
        with self.assertRaises(ValidationError):
            Client("C2", "Luis Díaz", "correo-invalido", "3101234567")

    def test_cost_with_tax_and_discount(self):
        self.assertEqual(self.room.calculate_cost(2, 0.19, 0.10), 107100.0)

    def test_equipment_quantity(self):
        equipment = EquipmentRental("S2", 10000, "Proyector")
        self.assertEqual(equipment.calculate_cost(2, quantity=3), 60000.0)

    def test_reservation_lifecycle(self):
        reservation = self.app.create_reservation("R1", "C1", "S1", 2)
        reservation.confirm()
        self.assertEqual(reservation.process(), 100000.0)
        self.assertEqual(reservation.status, "PROCESADA")

    def test_unconfirmed_reservation_is_chained(self):
        reservation = self.app.create_reservation("R1", "C1", "S1", 2)
        with self.assertRaises(RuntimeError) as context:
            reservation.process()
        self.assertIsNotNone(context.exception.__cause__)

    def test_unavailable_service(self):
        service = SpecializedConsulting("S2", 80000, "Redes", available=False)
        self.app.add_service(service)
        reservation = self.app.create_reservation("R2", "C1", "S2", 1)
        with self.assertRaises(ServiceUnavailableError):
            reservation.confirm()


if __name__ == "__main__":
    unittest.main()
